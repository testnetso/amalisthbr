const { Keypair, Connection, PublicKey } = require('@solana/web3.js');
const { findReference, validateTransfer } = require('@solana/pay');
const { URL } = require('url');
const BigNumber = require('bignumber.js');
const { getPackage, getAllPackages } = require('../config/packages');
const { pool } = require('../config/db');


// @desc    Get all available credit packages
// @route   GET /api/payments/packages
// @access  Private
exports.getPackages = (req, res, next) => {
    try {
        const packages = getAllPackages();
        res.status(200).json({ success: true, data: packages });
    } catch (error) {
        res.status(500).json({ success: false, error: 'Server Error' });
    }
};

// @desc    Generate a Solana Pay payment request URL
// @route   POST /api/payments/create-transaction
// @access  Private
exports.createTransaction = async (req, res, next) => {
    let connection;
    try {
        const { packageId, walletAddress } = req.body;

        if (!packageId || !walletAddress) {
            return res.status(400).json({ success: false, error: 'Package ID and wallet address are required.' });
        }

        const pkg = getPackage(packageId);
        if (!pkg) {
            return res.status(404).json({ success: false, error: 'Package not found.' });
        }

        const reference = new Keypair().publicKey.toBase58();
        const recipient = process.env.SHOP_SOLANA_ADDRESS;
        const amount = new BigNumber(pkg.priceUSD);
        const label = 'HBR Trading IA';
        const memo = `Package: ${pkg.name} - UserID: ${req.user.id}`;
        // For simplicity, we'll use USDC for all transactions for now.
        const splToken = new PublicKey(process.env.USDC_MINT_ADDRESS);

        connection = await pool.getConnection();
        const sql = 'INSERT INTO payment_references (reference, user_id, packageId, status) VALUES (?, ?, ?, ?)';
        await connection.query(sql, [reference, req.user.id, pkg.id, 'pending']);

        const paymentUrl = new URL(`solana:${recipient}`);
        paymentUrl.searchParams.append('amount', amount.toString());
        paymentUrl.searchParams.append('spl-token', splToken.toBase58());
        paymentUrl.searchParams.append('reference', reference);
        paymentUrl.searchParams.append('label', label);
        paymentUrl.searchParams.append('memo', memo);

        res.status(200).json({
            success: true,
            data: {
                transactionUrl: paymentUrl.toString(),
                reference: reference,
            },
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, error: 'Server Error' });
    } finally {
        if (connection) connection.release();
    }
};


// @desc    Verify a Solana transaction and credit user
// @route   GET /api/payments/verify-transaction
// @access  Private
exports.verifyTransaction = async (req, res, next) => {
    let dbConnection;
    try {
        const { reference } = req.query;
        if (!reference) {
            return res.status(400).json({ success: false, error: 'Reference is required.' });
        }

        dbConnection = await pool.getConnection();

        // 1. Find the payment reference in the database
        const [refs] = await dbConnection.query('SELECT * FROM payment_references WHERE reference = ?', [reference]);
        if (refs.length === 0) {
            return res.status(404).json({ success: false, error: 'Payment reference not found.' });
        }
        const paymentRef = refs[0];

        if (paymentRef.status === 'confirmed') {
            return res.status(200).json({ success: true, data: { status: 'confirmed', message: 'Payment already confirmed.' } });
        }

        const pkg = getPackage(paymentRef.packageId);
        if (!pkg) {
             await dbConnection.query("UPDATE payment_references SET status = 'failed' WHERE reference = ?", [reference]);
             return res.status(404).json({ success: false, data: { status: 'failed', message: 'Package not found for this reference.' } });
        }

        // 2. Set up Solana connection
        const solanaConnection = new Connection(process.env.SOLANA_RPC_ENDPOINT, 'confirmed');

        // 3. Find the transaction signature using the reference
        const signatureInfo = await findReference(solanaConnection, new PublicKey(reference), { finality: 'confirmed' });

        // 4. Validate the transaction
        const splToken = new PublicKey(process.env.USDC_MINT_ADDRESS);
        const amount = new BigNumber(pkg.priceUSD);
        const recipient = new PublicKey(process.env.SHOP_SOLANA_ADDRESS);

        await validateTransfer(
            solanaConnection,
            signatureInfo.signature,
            { recipient, amount, splToken, reference: new PublicKey(reference) },
            { commitment: 'confirmed' }
        );

        // 5. All checks passed, update database in a transaction
        await dbConnection.beginTransaction();

        // Add credits to user
        const updateUserSql = 'UPDATE users SET credits = credits + ? WHERE id = ?';
        await dbConnection.query(updateUserSql, [pkg.totalCredits, paymentRef.user_id]);

        // Log the purchase transaction
        const insertTxSql = 'INSERT INTO transactions (user_id, type, amount, details) VALUES (?, ?, ?, ?)';
        await dbConnection.query(insertTxSql, [paymentRef.user_id, 'purchase', pkg.totalCredits, `Purchased package: ${pkg.name}`]);

        // Mark reference as confirmed
        const updateRefSql = "UPDATE payment_references SET status = 'confirmed' WHERE reference = ?";
        await dbConnection.query(updateRefSql, [reference]);

        await dbConnection.commit();

        res.status(200).json({ success: true, data: { status: 'confirmed', message: 'Payment verified and credits added.' } });

    } catch (error) {
        console.error('Payment verification failed:', error);
        if (dbConnection) await dbConnection.rollback();

        if (error.name === 'ValidateTransferError') {
             return res.status(400).json({ success: false, data: { status: 'failed', message: 'Transaction validation failed on-chain.' } });
        }
        if (error.message.includes('findReference')) { // Or check for specific error codes
            return res.status(200).json({ success: true, data: { status: 'pending', message: 'Transaction not found yet, still pending...' } });
        }
        res.status(500).json({ success: false, data: { status: 'failed', message: 'An internal server error occurred.' } });
    } finally {
        if (dbConnection) dbConnection.release();
    }
};
