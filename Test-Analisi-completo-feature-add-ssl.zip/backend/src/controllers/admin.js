const { pool } = require('../config/db');

// @desc    Get dashboard stats
// @route   GET /api/admin/stats
// @access  Private/Admin
exports.getStats = async (req, res, next) => {
    let connection;
    try {
        connection = await pool.getConnection();

        const [usersResult] = await connection.query('SELECT COUNT(*) as totalUsers FROM users');
        const [recentResult] = await connection.query("SELECT COUNT(*) as recentRegistrations FROM users WHERE createdAt >= NOW() - INTERVAL 3 DAY");
        const [activeResult] = await connection.query("SELECT COUNT(*) as activeUsers FROM users WHERE lastLogin >= NOW() - INTERVAL 7 DAY");

        res.status(200).json({
            success: true,
            data: {
                totalUsers: usersResult[0].totalUsers,
                recentRegistrations: recentResult[0].recentRegistrations,
                activeUsers: activeResult[0].activeUsers,
            }
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, error: 'Server Error' });
    } finally {
        if (connection) connection.release();
    }
};

// @desc    Get all users with pagination and search
// @route   GET /api/admin/users
// @access  Private/Admin
exports.getUsers = async (req, res, next) => {
    let connection;
    try {
        connection = await pool.getConnection();

        const page = parseInt(req.query.page, 10) || 1;
        const limit = parseInt(req.query.limit, 10) || 10;
        const searchTerm = req.query.name || '';
        const offset = (page - 1) * limit;

        let whereClause = '';
        let queryParams = [];

        if (searchTerm) {
            whereClause = 'WHERE name LIKE ? OR email LIKE ?';
            queryParams.push(`%${searchTerm}%`, `%${searchTerm}%`);
        }

        // Get total count for pagination
        const countSql = `SELECT COUNT(*) as total FROM users ${whereClause}`;
        const [totalResult] = await connection.query(countSql, queryParams);
        const total = totalResult[0].total;

        // Get paginated users
        const usersSql = `SELECT id, name, email, role, credits, createdAt, lastLogin FROM users ${whereClause} ORDER BY createdAt DESC LIMIT ? OFFSET ?`;
        const [users] = await connection.query(usersSql, [...queryParams, limit, offset]);

        const pagination = {};
        if (offset + users.length < total) {
            pagination.next = { page: page + 1, limit };
        }
        if (offset > 0) {
            pagination.prev = { page: page - 1, limit };
        }

        res.status(200).json({ success: true, count: users.length, pagination, data: users });

    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, error: 'Server Error' });
    } finally {
        if (connection) connection.release();
    }
};

// @desc    Add or remove credits from a user
// @route   POST /api/admin/users/:id/add-credits
// @access  Private/Admin
exports.addCredits = async (req, res, next) => {
    let connection;
    try {
        const userId = req.params.id;
        const { amount } = req.body;

        if (!amount || isNaN(amount)) {
            return res.status(400).json({ success: false, error: 'Please provide a valid amount' });
        }

        const parsedAmount = parseInt(amount, 10);

        connection = await pool.getConnection();
        await connection.beginTransaction();

        // Update user's credits
        const updateUserSql = 'UPDATE users SET credits = credits + ? WHERE id = ?';
        await connection.query(updateUserSql, [parsedAmount, userId]);

        // Log the transaction
        const insertTxSql = 'INSERT INTO transactions (user_id, type, amount, details) VALUES (?, ?, ?, ?)';
        await connection.query(insertTxSql, [userId, 'admin_grant', parsedAmount, 'Admin credit adjustment']);

        // Fetch the updated user to return
        const [updatedUserRows] = await connection.query('SELECT * FROM users WHERE id = ?', [userId]);

        if (updatedUserRows.length === 0) {
            throw new Error('User not found after update.');
        }

        await connection.commit();

        res.status(200).json({ success: true, data: updatedUserRows[0] });

    } catch (error) {
        if (connection) await connection.rollback();
        console.error(error);
        res.status(500).json({ success: false, error: 'Server Error' });
    } finally {
        if (connection) connection.release();
    }
};
