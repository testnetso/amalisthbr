const { pool } = require('../config/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Helper function to sign JWT
const getSignedJwtToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRE,
  });
};

// Get token from model, create cookie and send response
const sendTokenResponse = (user, statusCode, res) => {
  // Create token
  const token = getSignedJwtToken(user.id);

  const options = {
    expires: new Date(
      Date.now() + process.env.JWT_COOKIE_EXPIRE * 24 * 60 * 60 * 1000
    ),
    httpOnly: true,
  };

  if (process.env.NODE_ENV === 'production') {
    options.secure = true;
  }

  res
    .status(statusCode)
    .cookie('token', token, options)
    .json({
      success: true,
      token,
      user: { // Send back some user info
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role
      }
    });
};


// @desc    Register user
// @route   POST /api/auth/register
// @access  Public
exports.register = async (req, res, next) => {
  const { name, email, password } = req.body;
  let connection;

  try {
    connection = await pool.getConnection();

    // Check if user already exists
    const [users] = await connection.query('SELECT id FROM users WHERE email = ?', [email]);
    if (users.length > 0) {
      return res.status(400).json({ success: false, error: 'User already exists' });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Insert new user
    const [result] = await connection.query('INSERT INTO users (name, email, password) VALUES (?, ?, ?)', [name, email, hashedPassword]);
    const newUserId = result.insertId;

    // Log welcome credits transaction
    await connection.query('INSERT INTO transactions (user_id, type, amount, details) VALUES (?, ?, ?, ?)', [newUserId, 'bonus', 1000, 'Welcome bonus credits']);

    // Fetch the newly created user to send in the response
    const [newUser] = await connection.query('SELECT id, name, email, role FROM users WHERE id = ?', [newUserId]);

    sendTokenResponse(newUser[0], 201, res);

  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: 'Server Error' });
  } finally {
      if (connection) connection.release();
  }
};

// @desc    Login user
// @route   POST /api/auth/login
// @access  Public
exports.login = async (req, res, next) => {
  const { email, password } = req.body;
  let connection;

  // Validate email & password
  if (!email || !password) {
    return res.status(400).json({ success: false, error: 'Please provide an email and password' });
  }

  try {
    connection = await pool.getConnection();

    // Check for user
    const [users] = await connection.query('SELECT * FROM users WHERE email = ?', [email]);
    if (users.length === 0) {
      return res.status(401).json({ success: false, error: 'Invalid credentials' });
    }
    const user = users[0];

    // Check if password matches
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ success: false, error: 'Invalid credentials' });
    }

    // Update lastLogin timestamp
    await connection.query('UPDATE users SET lastLogin = CURRENT_TIMESTAMP WHERE id = ?', [user.id]);

    sendTokenResponse(user, 200, res);

  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: 'Server Error' });
  } finally {
      if (connection) connection.release();
  }
};

// @desc    Get current logged in user
// @route   GET /api/auth/me
// @access  Private
exports.getMe = async (req, res, next) => {
    // req.user is set by the protect middleware. We'll assume it has the user's data.
    // The middleware itself will need to be updated to fetch from MySQL.
    if (!req.user) {
        return res.status(401).json({ success: false, error: 'Not authorized' });
    }
    res.status(200).json({ success: true, data: req.user });
};

// @desc    Google auth callback
// @route   GET /api/auth/google/callback
// @access  Public
exports.googleCallback = (req, res, next) => {
  // This will require significant changes in the passport config to work with MySQL.
  // For now, it will likely be broken. We are focusing on the main email/password flow.
  if (!req.user) {
    return res.redirect('/login.html?error=google_auth_failed');
  }
  sendTokenResponse(req.user, 200, res);
};
