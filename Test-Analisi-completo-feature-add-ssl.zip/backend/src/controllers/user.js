const { pool } = require('../config/db');

// @desc    Get user dashboard data
// @route   GET /api/user/dashboard
// @access  Private
exports.getDashboard = async (req, res, next) => {
  let connection;
  try {
    connection = await pool.getConnection();
    const [transactions] = await connection.query(
      'SELECT * FROM transactions WHERE user_id = ? ORDER BY createdAt DESC LIMIT 50',
      [req.user.id]
    );

    res.status(200).json({
      success: true,
      data: {
        credits: req.user.credits,
        isVip: req.user.role === 'admin', // Or some other VIP logic
        vipExpiresAt: null, // VIP expiry logic can be added later
        history: transactions,
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: 'Server Error' });
  } finally {
      if(connection) connection.release();
  }
};

// @desc    Get user profile
// @route   GET /api/user/profile
// @access  Private
exports.getUserProfile = async (req, res, next) => {
  try {
    // req.user is already populated by the 'protect' middleware
    const user = req.user;
    res.status(200).json({
      success: true,
      data: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        credits: user.credits,
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: 'Server Error' });
  }
};
