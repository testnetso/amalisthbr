const https = require('https');
const fs = require('fs');
const path = require('path');
const app = require('./app');
const { testConnection } = require('./config/db');

// Test the database connection on startup
testConnection();

const PORT = process.env.PORT || 3001;
const HTTPS_PORT = process.env.HTTPS_PORT || 3002;

// SSL certificate options
const options = {
  key: fs.readFileSync(path.join(__dirname, '..', 'certs', 'key.pem')),
  cert: fs.readFileSync(path.join(__dirname, '..', 'certs', 'cert.pem'))
};

// Create HTTPS server
const httpsServer = https.createServer(options, app);

httpsServer.listen(HTTPS_PORT, () => {
  console.log(`HTTPS Server running on port ${HTTPS_PORT}`);
});

// For development, also keep the HTTP server
const httpServer = app.listen(PORT, () => {
  console.log(`HTTP Server running on port ${PORT}`);
});

// Handle graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM signal received: closing servers');
  httpsServer.close(() => {
    console.log('HTTPS server closed');
  });
  httpServer.close(() => {
    console.log('HTTP server closed');
  });
});