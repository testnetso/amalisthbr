// =============================================
// LIBRERÍA COMPLETA: 100 INDICADORES TÉCNICOS PARA CRYPTO
// Implementación en Node.js puro - Sin dependencias externas
// =============================================

class CryptoTechnicalIndicators {

    // =============================================
    // INDICADORES DE TENDENCIA (1-25)
    // =============================================

    // 1. Media Móvil Simple (SMA)
    static sma(data, period) {
        if (period > data.length) return [];
        const result = [];
        for (let i = period - 1; i < data.length; i++) {
            const sum = data.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
            result.push(sum / period);
        }
        return result;
    }

    // 2. Media Móvil Exponencial (EMA)
    static ema(data, period) {
        if (period > data.length || data.length === 0) return [];
        const multiplier = 2 / (period + 1);
        const result = [data[0]];
        for (let i = 1; i < data.length; i++) {
            result.push((data[i] * multiplier) + (result[i - 1] * (1 - multiplier)));
        }
        return result;
    }

    // 3. Media Móvil Ponderada (WMA)
    static wma(data, period) {
        if (period > data.length) return [];
        const result = [];
        const denominator = (period * (period + 1)) / 2;
        for (let i = period - 1; i < data.length; i++) {
            let numerator = 0;
            for (let j = 0; j < period; j++) {
                numerator += data[i - j] * (period - j);
            }
            result.push(numerator / denominator);
        }
        return result;
    }

    // 4. MACD (Moving Average Convergence Divergence)
    static macd(data, fast = 12, slow = 26, signal = 9) {
        const emaFast = this.ema(data, fast);
        const emaSlow = this.ema(data, slow);
        if (emaFast.length === 0 || emaSlow.length === 0) return { macd: [], signal: [], histogram: [] };

        const macdLine = [];
        const startOffset = emaSlow.length - emaFast.length;
        for (let i = startOffset; i < emaSlow.length; i++) {
            macdLine.push(emaFast[i] - emaSlow[i]);
        }

        const signalLine = this.ema(macdLine, signal);
        const histogram = macdLine.slice(macdLine.length - signalLine.length).map((val, i) => val - signalLine[i]);

        return { macd: macdLine, signal: signalLine, histogram };
    }

    // 5. Parabolic SAR
    static parabolicSAR(high, low, step = 0.02, max = 0.2) {
        if (high.length === 0) return [];
        const sar = [low[0]];
        let ep = high[0];
        let af = step;
        let isUptrend = true;

        for (let i = 1; i < high.length; i++) {
            let nextSar;
            if (isUptrend) {
                nextSar = sar[i-1] + af * (ep - sar[i-1]);
                if (low[i] < nextSar) {
                    isUptrend = false;
                    nextSar = ep;
                    ep = low[i];
                    af = step;
                } else {
                    if (high[i] > ep) {
                        ep = high[i];
                        af = Math.min(af + step, max);
                    }
                }
            } else {
                nextSar = sar[i-1] + af * (ep - sar[i-1]);
                if (high[i] > nextSar) {
                    isUptrend = true;
                    nextSar = ep;
                    ep = high[i];
                    af = step;
                } else {
                    if (low[i] < ep) {
                        ep = low[i];
                        af = Math.min(af + step, max);
                    }
                }
            }
            sar.push(nextSar);
        }
        return sar;
    }

    // 6. ADX (Average Directional Index)
    static adx(high, low, close, period = 14) {
        if (high.length < period * 2) return { adx: [], pdi: [], ndi: [] };

        const {pdi, ndi} = this.dmi(high, low, close, period);
        const dx = pdi.map((val, i) => (Math.abs(val - ndi[i]) / (val + ndi[i])) * 100);
        const adxValues = this.sma(dx.filter(v => !isNaN(v)), period);

        return { adx: adxValues, pdi, ndi };
    }

    // Helper DMI for ADX
    static dmi(high, low, close, period=14) {
        const tr = this.trueRange(high, low, close);
        const dm_plus = [];
        const dm_minus = [];
        for(let i=1; i<high.length; i++){
            const upMove = high[i] - high[i-1];
            const downMove = low[i-1] - low[i];
            dm_plus.push(upMove > downMove && upMove > 0 ? upMove : 0);
            dm_minus.push(downMove > upMove && downMove > 0 ? downMove : 0);
        }
        const atr = this.ema(tr, period);
        const smooth_dm_plus = this.ema(dm_plus, period);
        const smooth_dm_minus = this.ema(dm_minus, period);
        const pdi = smooth_dm_plus.map((val, i) => (val / atr[i]) * 100);
        const ndi = smooth_dm_minus.map((val, i) => (val / atr[i]) * 100);
        return {pdi, ndi};
    }

    // 7. Aroon
    static aroon(high, low, period = 14) {
        if (high.length < period) return { aroonUp: [], aroonDown: [] };
        const aroonUp = [];
        const aroonDown = [];

        for (let i = period -1; i < high.length; i++) {
            const hSlice = high.slice(i - period + 1, i + 1);
            const lSlice = low.slice(i - period + 1, i + 1);
            const highIndex = hSlice.indexOf(Math.max(...hSlice));
            const lowIndex = lSlice.indexOf(Math.min(...lSlice));

            aroonUp.push(((period - (hSlice.length - 1 - highIndex)) / period) * 100);
            aroonDown.push(((period - (lSlice.length - 1 - lowIndex)) / period) * 100);
        }

        return { aroonUp, aroonDown };
    }

    // 8. CCI (Commodity Channel Index)
    static cci(high, low, close, period = 20) {
        const tp = high.map((h, i) => (h + low[i] + close[i]) / 3);
        const smaTP = this.sma(tp, period);
        const result = [];

        for (let i = period - 1; i < tp.length; i++) {
            const slice = tp.slice(i - period + 1, i + 1);
            const sma = smaTP[i-period+1];
            const meanDev = slice.reduce((sum, val) => sum + Math.abs(val - sma), 0) / period;
            result.push((tp[i] - sma) / (0.015 * meanDev));
        }

        return result;
    }

    // 9. DPO (Detrended Price Oscillator)
    static dpo(data, period = 20) {
        const displacement = Math.floor(period / 2) + 1;
        const smaValues = this.sma(data, period);
        const result = [];

        for (let i = period - 1; i < data.length; i++) {
            if (i - displacement >= 0 && smaValues[i-period+1-displacement] !== undefined) {
               result.push(data[i] - smaValues[i-period+1-displacement]);
            }
        }
        return result;
    }

    // 10. Ichimoku Cloud
    static ichimoku(high, low, close, tenkan=9, kijun=26, senkou=52) {
        const tenkanSen = [];
        const kijunSen = [];
        for(let i=0; i<close.length; i++){
            if(i >= tenkan-1){
                const slice = close.slice(i-tenkan+1, i+1);
                tenkanSen.push((Math.max(...slice) + Math.min(...slice)) / 2);
            }
            if(i >= kijun-1){
                 const slice = close.slice(i-kijun+1, i+1);
                 kijunSen.push((Math.max(...slice) + Math.min(...slice)) / 2);
            }
        }
        const senkouSpanA = tenkanSen.map((val, i) => (val + kijunSen[i]) / 2).slice(kijun-tenkan);
        const senkouSpanB = [];
        for(let i=senkou-1; i<close.length; i++){
            const slice = close.slice(i-senkou+1, i+1);
            senkouSpanB.push((Math.max(...slice) + Math.min(...slice)) / 2);
        }
        const chikouSpan = close.slice(0, close.length-kijun);
        return { tenkanSen, kijunSen, senkouSpanA, senkouSpanB, chikouSpan };
    }

    // ... (rest of the 101 indicators, including the all-important runCompleteAnalysisWithSignals)

    /**
     * Análisis completo con señales para todos los indicadores
     * @param {Array} ohlcvData - Datos OHLCV
     * @returns {Object} Análisis completo con señales
     */
    static runCompleteAnalysisWithSignals(ohlcvData) {
        const closes = ohlcvData.map(d => d.close);
        const highs = ohlcvData.map(d => d.high);
        const lows = ohlcvData.map(d => d.low);
        const volumes = ohlcvData.map(d => d.volume);
        const currentPrice = closes[closes.length - 1];

        // Calcular todos los indicadores principales
        const indicators = {
            // Tendencia
            sma20: this.sma(closes, 20),
            sma50: this.sma(closes, 50),
            ema21: this.ema(closes, 21),
            macd: this.macd(closes),
            adx: this.adx(highs, lows, closes),
            parabolicSAR: this.parabolicSAR(highs, lows),
            aroon: this.aroon(highs, lows),

            // Momentum
            rsi: this.rsi(closes),
            stochastic: this.stochastic(highs, lows, closes),
            williamsR: this.williamsR(highs, lows, closes),
            cci: this.cci(highs, lows, closes),
            tsi: this.tsi(closes),
            mfi: this.mfi(highs, lows, closes, volumes),

            // Volatilidad
            bollingerBands: this.bollingerBands(closes),
            atr: this.atr(highs, lows, closes),

            // Volumen
            obv: this.obv(closes, volumes),
            vwap: this.vwap(highs, lows, closes, volumes),

            // Crypto específicos
            hbrIndicator: this.hbrIndicator(closes)
        };

        // Generar señales para cada indicador
        const signals = {};

        // Señales de tendencia
        signals.sma20 = this.getUnifiedSignal('sma', this.last(indicators.sma20), indicators.sma20.slice(-5), { currentPrice });
        signals.ema21 = this.getUnifiedSignal('ema', this.last(indicators.ema21), indicators.ema21.slice(-5), { currentPrice });
        signals.macd = this.getUnifiedSignal('macd', {
            macd: this.last(indicators.macd.macd),
            signal: this.last(indicators.macd.signal),
            histogram: this.last(indicators.macd.histogram)
        });
        signals.adx = this.getUnifiedSignal('adx', {
            adx: this.last(indicators.adx.adx),
            pdi: this.last(indicators.adx.pdi),
            ndi: this.last(indicators.adx.ndi)
        });
        signals.parabolicSAR = this.getUnifiedSignal('parabolicsar',
            this.last(indicators.parabolicSAR), [], { currentPrice });
        signals.aroon = this.getUnifiedSignal('aroon', {
            aroonUp: this.last(indicators.aroon.aroonUp),
            aroonDown: this.last(indicators.aroon.aroonDown)
        });

        // Señales de momentum
        signals.rsi = this.getUnifiedSignal('rsi', this.last(indicators.rsi));
        signals.stochastic = this.getUnifiedSignal('stochastic', {
            k: this.last(indicators.stochastic.k),
            d: this.last(indicators.stochastic.d)
        });
        signals.williamsR = this.getUnifiedSignal('williamsr',
            this.last(indicators.williamsR));
        signals.cci = this.getUnifiedSignal('cci', this.last(indicators.cci));
        signals.tsi = this.getUnifiedSignal('tsi', this.last(indicators.tsi),
            indicators.tsi.slice(-5));
        signals.mfi = this.getUnifiedSignal('mfi', this.last(indicators.mfi));

        // Señales de volatilidad
        signals.bollingerBands = this.getUnifiedSignal('bollingerbands', {
            upper: this.last(indicators.bollingerBands.upper),
            middle: this.last(indicators.bollingerBands.middle),
            lower: this.last(indicators.bollingerBands.lower)
        }, [], { currentPrice });

        // Señales de volumen
        signals.obv = this.getUnifiedSignal('obv',
            this.last(indicators.obv), indicators.obv.slice(-3));

        // Señales crypto específicas
        signals.hbrIndicator = this.last(indicators.hbrIndicator.signals);

        // Consenso general
        const allSignals = Object.values(signals).filter(s => s); // Filter out undefined signals
        const buyCount = allSignals.filter(s => s === 'COMPRA').length;
        const sellCount = allSignals.filter(s => s === 'VENTA').length;
        const neutralCount = allSignals.length - buyCount - sellCount;

        let overallSignal = 'NEUTRO';
        let confidence = 0;

        if (buyCount > sellCount) {
            overallSignal = 'COMPRA';
            confidence = (buyCount / allSignals.length) * 100;
        } else if (sellCount > buyCount) {
            overallSignal = 'VENTA';
            confidence = (sellCount / allSignals.length) * 100;
        } else {
            confidence = (neutralCount / allSignals.length) * 100;
        }

        return {
            indicators: signals, // Return the signals object for frontend display
            consensus: {
                signal: overallSignal,
                confidence: confidence.toFixed(1),
                distribution: {
                    compra: buyCount,
                    venta: sellCount,
                    neutro: neutralCount,
                    total: allSignals.length
                }
            },
            currentPrice,
            timestamp: Date.now()
        };
    }

    // Helper to get the last element of an array safely
    static last(arr) {
        if (arr && arr.length > 0) {
            return arr[arr.length - 1];
        }
        return undefined;
    }

    // ... (The rest of the class, including the other static methods)
}

module.exports = CryptoTechnicalIndicators;
