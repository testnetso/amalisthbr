const axios = require('axios');

const BINANCE_API_URL = 'https://api.binance.com/api/v3';

/**
 * Fetches kline/candlestick data from Binance.
 * @param {string} symbol The trading symbol (e.g., 'BTCUSDT').
 * @param {string} interval The interval (e.g., '1h', '4h', '1d').
 * @param {number} limit The number of data points to retrieve (max 1000).
 * @returns {Promise<Array>} A promise that resolves to an array of kline data arrays.
 */
const fetchKlines = async (symbol, interval = '1h', limit = 500) => {
  if (!symbol) {
    throw new Error('Symbol is required to fetch klines.');
  }

  try {
    const response = await axios.get(`${BINANCE_API_URL}/klines`, {
      params: {
        symbol: symbol.toUpperCase(),
        interval,
        limit,
      },
    });
    return response.data;
  } catch (error) {
    console.error(`Error fetching klines for ${symbol} from Binance:`, error.response ? error.response.data : error.message);
    // Re-throw a more generic error to not expose too many details to the client
    throw new Error('Failed to fetch data from Binance API.');
  }
};

/**
 * Fetches 24-hour ticker price change statistics from Binance.
 * @param {string} symbol The trading symbol (e.g., 'BTCUSDT').
 * @returns {Promise<Object>} A promise that resolves to the ticker data object.
 */
const fetchTickerData = async (symbol) => {
  if (!symbol) {
    throw new Error('Symbol is required to fetch ticker data.');
  }

  try {
    const response = await axios.get(`${BINANCE_API_URL}/ticker/24hr`, {
      params: {
        symbol: symbol.toUpperCase(),
      },
    });
    return response.data;
  } catch (error) {
    console.error(`Error fetching ticker data for ${symbol} from Binance:`, error.response ? error.response.data : error.message);
    throw new Error('Failed to fetch ticker data from Binance API.');
  }
};

const BINANCE_FUTURES_API_URL = 'https://fapi.binance.com/fapi/v1';

/**
 * Fetches all available futures symbols from Binance.
 * @returns {Promise<Array>} A promise that resolves to an array of symbol objects.
 */
const fetchFuturesSymbols = async () => {
  try {
    const response = await axios.get(`${BINANCE_FUTURES_API_URL}/exchangeInfo`);
    const symbols = response.data.symbols;
    // Filter for USDT pairs and format them
    return symbols
      .filter(s => s.quoteAsset === 'USDT' && s.status === 'TRADING')
      .map(s => ({
        id: s.symbol,
        name: `${s.baseAsset}/${s.quoteAsset}`
      }));
  } catch (error) {
    console.error(`Error fetching futures symbols from Binance:`, error.response ? error.response.data : error.message);
    throw new Error('Failed to fetch futures symbols from Binance API.');
  }
};


module.exports = {
  fetchKlines,
  fetchTickerData,
  fetchFuturesSymbols,
};