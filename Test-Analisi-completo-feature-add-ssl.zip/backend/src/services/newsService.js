const Parser = require('rss-parser');
const parser = new Parser();

const NEWS_FEED_URL = 'https://cointelegraph.com/rss';

/**
 * Fetches and parses crypto news from an RSS feed.
 * @returns {Promise<Array<Object>>} A promise that resolves to an array of news items.
 */
const fetchNews = async () => {
  try {
    const feed = await parser.parseURL(NEWS_FEED_URL);
    // Return a limited number of items to keep the UI clean
    return feed.items.slice(0, 5).map(item => ({
      title: item.title,
      link: item.link,
      snippet: item.contentSnippet,
      pubDate: item.pubDate,
    }));
  } catch (error) {
    console.error('Error fetching or parsing news feed:', error);
    throw new Error('Failed to fetch crypto news.');
  }
};

module.exports = {
  fetchNews,
};