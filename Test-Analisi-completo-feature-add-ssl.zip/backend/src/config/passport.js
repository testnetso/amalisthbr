// const GoogleStrategy = require('passport-google-oauth20').Strategy;
// const mongoose = require('mongoose');
// const User = require('../models/User'); // This line is causing the error

module.exports = function (passport) {
  // The Google Strategy is commented out as it depends on Mongoose.
  // This will be re-implemented when Google Login with MySQL is prioritized.

  // passport.use(
  //   new GoogleStrategy(...)
  // );

  // The serialize/deserialize functions also depend on the User model.
  // They are used for session management, typically with cookies.
  // Since we are using stateless JWTs, these are not strictly necessary
  // for the email/password flow but might be for Google's session-based flow.
  // We will comment them out to prevent Mongoose-related errors.

  // passport.serializeUser((user, done) => {
  //   done(null, user.id);
  // });

  // passport.deserializeUser((id, done) => {
  //   // This needs to be rewritten for MySQL if we use session-based auth
  //   // User.findById(id, (err, user) => done(err, user));
  // });
};
