// src/config/staticPairs.js
// Configuración estática de pares de trading para evitar errores de API

const STATIC_TRADING_PAIRS = [
  // Pares principales de Bitcoin
  { id: 'BTCUSDT', name: 'BTC/USDT' },
  { id: 'ETHUSDT', name: 'ETH/USDT' },
  
  // Top 10 Criptomonedas por Market Cap
  { id: 'BNBUSDT', name: 'BNB/USDT' },
  { id: 'SOLUSDT', name: 'SOL/USDT' },
  { id: 'XRPUSDT', name: 'XRP/USDT' },
  { id: 'DOGEUSDT', name: 'DOGE/USDT' },
  { id: 'ADAUSDT', name: 'ADA/USDT' },
  { id: 'AVAXUSDT', name: 'AVAX/USDT' },
  { id: 'DOTUSDT', name: 'DOT/USDT' },
  { id: 'TRXUSDT', name: 'TRX/USDT' },
  
  // DeFi Tokens populares
  { id: 'LINKUSDT', name: 'LINK/USDT' },
  { id: 'UNIUSDT', name: 'UNI/USDT' },
  { id: 'MATICUSDT', name: 'MATIC/USDT' },
  { id: 'AAVEUSDT', name: 'AAVE/USDT' },
  { id: 'SUSHIUSDT', name: 'SUSHI/USDT' },
  
  // Layer 2 y nuevas tecnologías
  { id: 'ARBUSDT', name: 'ARB/USDT' },
  { id: 'OPUSDT', name: 'OP/USDT' },
  { id: 'APTUSDT', name: 'APT/USDT' },
  { id: 'SUIUSDT', name: 'SUI/USDT' },
  
  // Meme coins populares
  { id: 'SHIBUSDT', name: 'SHIB/USDT' },
  { id: 'PEPEUSDT', name: 'PEPE/USDT' },
  { id: 'FLOKIUSDT', name: 'FLOKI/USDT' },
  
  // Exchange tokens
  { id: 'CAKEUSDT', name: 'CAKE/USDT' },
  { id: 'FTMUSDT', name: 'FTM/USDT' },
  
  // AI & Gaming tokens
  { id: 'FETUSDT', name: 'FET/USDT' },
  { id: 'RENDERUSDT', name: 'RENDER/USDT' },
  { id: 'AXSUSDT', name: 'AXS/USDT' },
  { id: 'SANDUSDT', name: 'SAND/USDT' },
  { id: 'MANAUSDT', name: 'MANA/USDT' },
  { id: 'GALAUSDT', name: 'GALA/USDT' },
  
  // Otros tokens importantes
  { id: 'ATOMUSDT', name: 'ATOM/USDT' },
  { id: 'NEARUSDT', name: 'NEAR/USDT' },
  { id: 'FILUSDT', name: 'FIL/USDT' },
  { id: 'LTCUSDT', name: 'LTC/USDT' },
  { id: 'BCHUSDT', name: 'BCH/USDT' },
  { id: 'ETCUSDT', name: 'ETC/USDT' },
  { id: 'XLMUSDT', name: 'XLM/USDT' },
  { id: 'ALGOUSDT', name: 'ALGO/USDT' },
  { id: 'VETUSDT', name: 'VET/USDT' },
  { id: 'ICPUSDT', name: 'ICP/USDT' },
  { id: 'INJUSDT', name: 'INJ/USDT' },
  { id: 'HBARUSDT', name: 'HBAR/USDT' },
  { id: 'KASUSDT', name: 'KAS/USDT' },
  { id: 'THETAUSDT', name: 'THETA/USDT' },
  { id: 'EGLDUSDT', name: 'EGLD/USDT' },
  { id: 'RUNEUSDT', name: 'RUNE/USDT' },
  { id: 'IMXUSDT', name: 'IMX/USDT' },
  { id: 'STXUSDT', name: 'STX/USDT' },
  { id: 'TIAUSDT', name: 'TIA/USDT' },
  { id: 'SEIUSDT', name: 'SEI/USDT' }
];

// Función para obtener todos los pares
function getAllStaticPairs() {
  return STATIC_TRADING_PAIRS;
}

// Función para buscar un par específico
function findPairById(id) {
  return STATIC_TRADING_PAIRS.find(pair => pair.id === id.toUpperCase());
}

// Función para verificar si un par existe
function isPairValid(id) {
  return STATIC_TRADING_PAIRS.some(pair => pair.id === id.toUpperCase());
}

// Función para obtener pares por categoría (opcional)
function getPairsByCategory(category) {
  const categories = {
    'major': ['BTCUSDT', 'ETHUSDT', 'BNBUSDT'],
    'defi': ['LINKUSDT', 'UNIUSDT', 'AAVEUSDT', 'SUSHIUSDT'],
    'meme': ['DOGEUSDT', 'SHIBUSDT', 'PEPEUSDT', 'FLOKIUSDT'],
    'layer2': ['ARBUSDT', 'OPUSDT', 'MATICUSDT'],
    'gaming': ['AXSUSDT', 'SANDUSDT', 'MANAUSDT', 'GALAUSDT'],
    'ai': ['FETUSDT', 'RENDERUSDT']
  };
  
  const pairIds = categories[category.toLowerCase()] || [];
  return STATIC_TRADING_PAIRS.filter(pair => pairIds.includes(pair.id));
}

module.exports = {
  STATIC_TRADING_PAIRS,
  getAllStaticPairs,
  findPairById,
  isPairValid,
  getPairsByCategory
};