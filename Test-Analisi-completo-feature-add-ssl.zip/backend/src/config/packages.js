const packages = {
    'p1': { id: 'p1', name: 'Básico', priceUSD: 5, credits: 1000, bonus: 0, totalCredits: 1000 },
    'p2': { id: 'p2', name: 'Starter', priceUSD: 10, credits: 2000, bonus: 0.10, totalCredits: 2200 },
    'p3': { id: 'p3', name: 'Avanzado', priceUSD: 20, credits: 4000, bonus: 0.15, totalCredits: 4600 },
    'p4': { id: 'p4', name: 'Pro', priceUSD: 50, credits: 10000, bonus: 0.25, totalCredits: 12500 },
    'p5': { id: 'p5', name: 'Premium', priceUSD: 100, credits: 20000, bonus: 0.30, totalCredits: 26000 },
    'p6': { id: 'p6', name: 'Titan', priceUSD: 250, credits: 60000, bonus: 0, totalCredits: 60000 },
    'vip': { id: 'vip', name: 'VIP Ilimitado', priceUSD: 500, credits: Infinity, durationDays: 30 }
};

const getPackage = (packageId) => {
    return packages[packageId];
};

const getAllPackages = () => {
    return Object.values(packages);
};

module.exports = {
    getPackage,
    getAllPackages,
};
