const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const { pool } = require('../config/db');
const { fetchKlines, fetchTickerData, fetchFuturesSymbols } = require('../services/binanceService');
const { fetchNews } = require('../services/newsService');
const CryptoTechnicalIndicators = require('../services/indicatorService');

// IMPORTAR CONFIGURACIÓN DE PARES ESTÁTICOS
const { getAllStaticPairs, isPairValid } = require('../config/staticPairs');

// --- CONFIGURACIÓN PARA USAR PARES ESTÁTICOS O DINÁMICOS ---
const USE_STATIC_PAIRS = true;

// --- Cache para pares ---
let tradingPairsCache = [];

// --- Main Analysis Route con 101 Indicadores ---
router.get('/analysis', protect, async (req, res) => {
    let connection;
    try {
        // Check user credits
        if (req.user.credits < 10) {
            return res.status(403).json({ success: false, message: 'Insufficient credits. Please recharge to continue analysis.' });
        }

        const { symbol, interval = '1h' } = req.query;
        if (!symbol) return res.status(400).json({ message: 'Symbol is required' });

        if (USE_STATIC_PAIRS && !isPairValid(symbol)) {
            return res.status(400).json({ 
                message: `Symbol ${symbol} is not in the list of available pairs.`
            });
        }

        // Fetch real-time data
        const klines = await fetchKlines(symbol, interval, 500);
        if (klines.length < 200) { // Ensure enough data for long-period indicators
            return res.status(400).json({ message: 'Not enough historical data for a full analysis.' });
        }
        
        // Format data for the new indicator library
        const ohlcvData = klines.map(k => ({
            open: parseFloat(k[1]),
            high: parseFloat(k[2]),
            low: parseFloat(k[3]),
            close: parseFloat(k[4]),
            volume: parseFloat(k[5])
        }));

        // Run the complete analysis using the new library
        const analysisResult = CryptoTechnicalIndicators.runCompleteAnalysisWithSignals(ohlcvData);

        // Deduct credits and log transaction atomically
        connection = await pool.getConnection();
        await connection.beginTransaction();

        const updateUserSql = 'UPDATE users SET credits = credits - 10 WHERE id = ? AND credits >= 10';
        const [updateResult] = await connection.query(updateUserSql, [req.user.id]);

        if (updateResult.affectedRows === 0) {
            await connection.rollback();
            return res.status(403).json({ success: false, message: 'Insufficient credits or user not found.' });
        }

        const insertTxSql = 'INSERT INTO transactions (user_id, type, amount, details) VALUES (?, ?, ?, ?)';
        await connection.query(insertTxSql, [req.user.id, 'spend', -10, `Analysis for symbol ${symbol} on interval ${interval}`]);

        await connection.commit();

        // Send the formatted response from the new library
        res.json({
            // The new library returns a slightly different structure.
            // We adapt it here to match the frontend's expectations.
            indicators: analysisResult.signals, // Send the signals for each indicator
            finalAnalysis: {
                signal: analysisResult.consensus.signal,
                confidence: analysisResult.consensus.confidence,
                summary: `Análisis basado en 101 indicadores técnicos profesionales con configuración personalizada.`,
                counts: analysisResult.consensus.distribution,
            }
        });
        
    } catch (error) {
        if (connection) await connection.rollback();
        console.error(`Error in /analysis for ${req.query.symbol}:`, error.message);
        res.status(500).json({ message: `Failed to generate analysis: ${error.message}` });
    } finally {
        if (connection) connection.release();
    }
});

// --- Other Routes (unchanged) ---
router.get('/news', protect, async (req, res) => {
    try {
        const newsItems = await fetchNews();
        res.json(newsItems);
    } catch (error) {
        res.status(500).json({ message: 'Failed to fetch news.' });
    }
});

router.get('/market-data', protect, async (req, res) => {
    try {
        const { symbol } = req.query;
        if (!symbol) return res.status(400).json({ message: 'Symbol is required' });
        
        if (USE_STATIC_PAIRS && !isPairValid(symbol)) {
            return res.status(400).json({ 
                message: `Symbol ${symbol} is not in the list of available pairs.` 
            });
        }
        
        const data = await fetchTickerData(symbol);
        res.json(data);
    } catch (error) {
        res.status(500).json({ message: 'Failed to fetch market data.' });
    }
});

router.get('/pairs', protect, (req, res) => {
    res.json(tradingPairsCache);
});

// --- Startup Data Loading (unchanged) ---
async function loadInitialData() {
    try {
        if (USE_STATIC_PAIRS) {
            console.log("📌 Using STATIC trading pairs configuration...");
            tradingPairsCache = getAllStaticPairs();
            console.log(`✅ Successfully loaded ${tradingPairsCache.length} STATIC trading pairs.`);
        } else {
            console.log("🔄 Fetching Binance Futures symbols from API...");
            tradingPairsCache = await fetchFuturesSymbols();
            console.log(`✅ Successfully loaded ${tradingPairsCache.length} symbols from Binance API.`);
        }
    } catch (error) {
        console.error("❌ CRITICAL ERROR: Could not load trading pairs, falling back to static list.");
        tradingPairsCache = getAllStaticPairs();
    }
}

loadInitialData();

module.exports = router;