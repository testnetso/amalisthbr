const express = require('express');
const { getDashboard, getUserProfile } = require('../controllers/user');
const { protect } = require('../middleware/auth');

const router = express.Router();

// All routes in this file are protected
router.use(protect);

router.get('/dashboard', getDashboard);
router.get('/profile', getUserProfile);

module.exports = router;
