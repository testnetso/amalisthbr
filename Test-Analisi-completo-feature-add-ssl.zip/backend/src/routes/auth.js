const express = require('express');
// const passport = require('passport');
const { register, login, getMe } = require('../controllers/auth');
const { protect } = require('../middleware/auth');

const router = express.Router();

// // @desc    Auth with Google
// // @route   GET /api/auth/google
// router.get('/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

// // @desc    Google auth callback
// // @route   GET /api/auth/google/callback
// router.get(
//   '/google/callback',
//   passport.authenticate('google', { failureRedirect: '/login' }), // assuming a /login frontend route
//   (req, res) => {
//     // Successful authentication, redirect home.
//     res.redirect('/');
//   }
// );

router.post('/register', register);
router.post('/login', login);
router.get('/me', protect, getMe);

module.exports = router;
