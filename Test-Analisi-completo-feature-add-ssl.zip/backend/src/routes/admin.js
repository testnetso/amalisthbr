const express = require('express');
const { getStats, getUsers, addCredits } = require('../controllers/admin');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// All routes in this file are protected and for admins only
router.use(protect);
router.use(authorize('admin'));

router.get('/stats', getStats);
router.get('/users', getUsers);
router.post('/users/:id/credits', addCredits);

module.exports = router;
