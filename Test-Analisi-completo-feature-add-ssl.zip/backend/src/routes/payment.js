const express = require('express');
const {
    getPackages,
    createTransaction,
    verifyTransaction
} = require('../controllers/payment');
const { protect } = require('../middleware/auth');

const router = express.Router();

// Public route to get packages
router.get('/packages', getPackages);

// All subsequent routes in this file are protected
router.use(protect);

router.post('/create-transaction', createTransaction);
router.get('/verify-transaction', verifyTransaction);

module.exports = router;
