const dotenv = require('dotenv');
// Load env vars right at the top
dotenv.config({ path: __dirname + '/../.env' });

const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const passport = require('passport');

// Passport config
require('./config/passport')(passport);

const app = express();

// Passport middleware
app.use(passport.initialize());

// Body parser
app.use(express.json());

// Cookie parser
app.use(cookieParser());

// Enable CORS
// I will configure CORS more securely later. For now, it allows all origins.
app.use(cors());

// API Routes
const apiRoutes = require('./routes/api');
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/user');
const paymentRoutes = require('./routes/payment');
const adminRoutes = require('./routes/admin');
app.use('/api', apiRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/admin', adminRoutes);

// A simple default route for testing
app.get('/', (req, res) => {
    res.send('Crypto Trading Dashboard Backend is up!');
});

module.exports = app;