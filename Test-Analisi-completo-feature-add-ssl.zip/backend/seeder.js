const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');
const bcrypt = require('bcryptjs');
const { pool } = require('./src/config/db');

// Load env vars
dotenv.config({ path: path.join(__dirname, '.env') });

// Import into DB
const importData = async () => {
  let connection;
  try {
    connection = await pool.getConnection();
    console.log('Database connected for seeding...');

    // Drop tables in reverse order of creation due to foreign key constraints
    console.log('Destroying existing data...');
    await connection.execute('SET FOREIGN_KEY_CHECKS = 0;');
    await connection.execute('DROP TABLE IF EXISTS transactions');
    await connection.execute('DROP TABLE IF EXISTS payment_references');
    await connection.execute('DROP TABLE IF EXISTS users');
    await connection.execute('SET FOREIGN_KEY_CHECKS = 1;');
    console.log('Data Destroyed...');

    // Read and execute schema.sql to create tables
    console.log('Creating schema...');
    const schemaSql = fs.readFileSync(path.join(__dirname, 'src', 'config', 'schema.sql'), 'utf-8');
    const sqlStatements = schemaSql.split(';').filter(statement => statement.trim() !== '');
    for (const statement of sqlStatements) {
        await connection.execute(statement);
    }
    console.log('Schema Created...');

    // Create default admin user
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash('password123', salt);

    const adminUser = {
      name: 'Admin User',
      email: 'admin@example.com',
      password: hashedPassword,
      role: 'admin',
      credits: 999999,
    };

    const insertUserSql = 'INSERT INTO users (name, email, password, role, credits) VALUES (?, ?, ?, ?, ?)';
    await connection.query(insertUserSql, [
        adminUser.name,
        adminUser.email,
        adminUser.password,
        adminUser.role,
        adminUser.credits
    ]);

    console.log('Admin user imported...');
    console.log('Data Imported successfully!');

  } catch (err) {
    console.error('Error during data import:', err);
    process.exit(1);
  } finally {
    if (connection) await connection.release();
    pool.end();
  }
};

// Delete data
const deleteData = async () => {
    let connection;
    try {
        connection = await pool.getConnection();
        console.log('Database connected for data destruction...');

        await connection.execute('SET FOREIGN_KEY_CHECKS = 0;');
        await connection.execute('DROP TABLE IF EXISTS transactions');
        await connection.execute('DROP TABLE IF EXISTS payment_references');
        await connection.execute('DROP TABLE IF EXISTS users');
        await connection.execute('SET FOREIGN_KEY_CHECKS = 1;');

        console.log('Data Destroyed...');
    } catch (err) {
        console.error('Error during data destruction:', err);
        process.exit(1);
    } finally {
        if (connection) await connection.release();
        pool.end();
    }
};

if (process.argv[2] === '-i') {
  importData();
} else if (process.argv[2] === '-d') {
  deleteData();
} else {
  console.log('Please use the -i or -d flag to import or destroy data.');
  process.exit();
}
