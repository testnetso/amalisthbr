document.addEventListener('DOMContentLoaded', () => {
    const creditBalanceEl = document.getElementById('credit-balance');
    const vipStatusCardEl = document.getElementById('vip-status-card');
    const vipExpiresEl = document.getElementById('vip-expires');
    const historyBodyEl = document.getElementById('history-body');
    const logoutBtn = document.getElementById('logout-btn');

    const token = localStorage.getItem('token');
    const API_BASE_URL = `https://${window.location.hostname}:3002`;

    // If no token, redirect to login. This is a fallback for the main app.js check.
    if (!token) {
        window.location.href = 'login.html';
        return;
    }

    const getAuthHeaders = () => ({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
    });

    const handleApiError = (error) => {
        console.error('API Error:', error);
        if (error.message.includes('401')) { // Crude check for unauthorized
            localStorage.removeItem('token');
            window.location.href = 'login.html';
        }
    };

    const fetchAndRenderDashboardData = async () => {
        try {
            const res = await fetch(`${API_BASE_URL}/api/user/dashboard`, { headers: getAuthHeaders() });
            if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
            const { data } = await res.json();

            // Render credits
            creditBalanceEl.textContent = data.credits.toLocaleString();

            // Render VIP status if applicable
            if (data.isVip) {
                vipStatusCardEl.style.display = 'block';
                vipExpiresEl.textContent = `Expira: ${new Date(data.vipExpiresAt).toLocaleDateString()}`;
            }

            // Render history
            historyBodyEl.innerHTML = ''; // Clear existing
            data.history.forEach(tx => {
                const row = document.createElement('tr');
                const amountClass = tx.amount > 0 ? 'amount-green' : 'amount-red';
                row.innerHTML = `
                    <td>${new Date(tx.createdAt).toLocaleString()}</td>
                    <td>${tx.type}</td>
                    <td class="${amountClass}">${tx.amount.toLocaleString()}</td>
                    <td>${tx.details || ''}</td>
                `;
                historyBodyEl.appendChild(row);
            });

        } catch (error) {
            handleApiError(error);
        }
    };

    const initialize = () => {
        fetchAndRenderDashboardData();

        logoutBtn.addEventListener('click', () => {
            localStorage.removeItem('token');
            window.location.href = 'login.html';
        });
    };

    initialize();
});
