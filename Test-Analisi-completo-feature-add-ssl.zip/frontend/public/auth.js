document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const googleButtons = document.querySelectorAll('.btn-google');
    const messageArea = document.getElementById('auth-message');
    const tabs = document.querySelectorAll('.tab-link');
    const tabContents = document.querySelectorAll('.tab-content');

    const API_URL = `https://${window.location.hostname}:3002/api/auth`;

    // Tab switching logic
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(item => item.classList.remove('active'));
            tab.classList.add('active');

            const target = document.getElementById(tab.dataset.tab);
            tabContents.forEach(content => content.classList.remove('active'));
            target.classList.add('active');
            messageArea.textContent = '';
            messageArea.className = 'auth-message';
        });
    });

    // Display messages
    const showMessage = (message, isError = false) => {
        messageArea.textContent = message;
        messageArea.className = 'auth-message'; // Reset classes
        if (isError) {
            messageArea.classList.add('error');
        } else {
            messageArea.classList.add('success');
        }
    };

    // Login form handler
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('login-email').value;
            const password = document.getElementById('login-password').value;

            try {
                const res = await fetch(`${API_URL}/login`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password }),
                });

                const data = await res.json();
                if (!res.ok) {
                    throw new Error(data.error || 'Something went wrong');
                }

                localStorage.setItem('token', data.token);
                showMessage('Login successful! Redirecting...', false);
                window.location.href = 'index.html';

            } catch (err) {
                showMessage(err.message, true);
            }
        });
    }

    // Register form handler
    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const name = document.getElementById('register-name').value;
            const email = document.getElementById('register-email').value;
            const password = document.getElementById('register-password').value;

            if (password.length < 6) {
                showMessage('Password must be at least 6 characters long.', true);
                return;
            }

            try {
                const res = await fetch(`${API_URL}/register`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name, email, password }),
                });

                const data = await res.json();
                if (!res.ok) {
                    throw new Error(data.error || 'Something went wrong');
                }

                localStorage.setItem('token', data.token);
                showMessage('Registration successful! Redirecting...', false);
                window.location.href = 'index.html';

            } catch (err) {
                showMessage(err.message, true);
            }
        });
    }

    // Google button handler
    googleButtons.forEach(button => {
        button.addEventListener('click', () => {
            window.location.href = `${API_URL}/google`;
        });
    });
});
