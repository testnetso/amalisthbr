// Access Wall - redirect if no token
const token = localStorage.getItem('token');
if (!token && !window.location.pathname.includes('login.html')) {
    window.location.href = 'login.html';
}

document.addEventListener('DOMContentLoaded', () => {
    const API_BASE_URL = `https://${window.location.hostname}:3002/api`;
    const token = localStorage.getItem('token');

    // Helper to get auth headers
    const getAuthHeaders = () => {
        const headers = {
            'Content-Type': 'application/json',
        };
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }
        return headers;
    };

    // Helper to handle fetch responses
    const handleResponse = async (res) => {
        // If we get a 401 Unauthorized, the token is bad, so we clear it and reload to trigger the access wall.
        if (res.status === 401) {
            localStorage.removeItem('token');
            window.location.href = 'login.html';
            return; // Stop further execution
        }

        const data = await res.json();
        if (!res.ok) {
            throw new Error(data.message || 'An error occurred');
        }
        return data;
    };

    // --- DOM Elements ---
    const pairSelector = document.getElementById('pairSelector');
    const pairList = document.getElementById('pair-list');
    const timeSelector = document.getElementById('timeSelector');
    const analyzeBtn = document.getElementById('analyzeBtn');
    const creditBalanceEl = document.getElementById('main-credit-balance');
    const chartContainer = document.getElementById('chartContainer');
    const indicatorsGrid = document.getElementById('indicators-grid');
    const analysisSummaryCard = document.getElementById('analysis-summary-card');
    const keyIndicatorsCard = document.getElementById('key-indicators-card');
    const marketDataCard = document.getElementById('market-data-card');
    const newsFeedCard = document.getElementById('news-feed-card');

    let tradingViewWidget;
    let lastAnalysisData = null;
    let autoRefreshInterval = null;

    // --- MEJORAS: Funciones Auxiliares ---

    // Verificar estado del backend
    async function checkBackendStatus() {
        const statusDot = document.querySelector('.status-dot');
        const statusText = document.querySelector('.status-indicator span:last-child');
        
        try {
            await fetch(`${API_BASE_URL}/pairs`, { headers: getAuthHeaders() }).then(handleResponse);
            statusDot.style.background = '#00ff00';
            statusText.textContent = 'IA Activa';
            return true;
        } catch (error) {
            statusDot.style.background = '#ff3232';
            statusText.textContent = 'Sin Conexión';
            return false;
        }
    }

    // Guardar/cargar último par
    function saveLastPair(symbol) {
        localStorage.setItem('lastAnalyzedPair', symbol);
    }

    function loadLastPair() {
        const lastPair = localStorage.getItem('lastAnalyzedPair');
        if (lastPair && window.availablePairs?.some(p => p.id === lastPair)) {
            return lastPair;
        }
        return 'BTCUSDT';
    }

    async function updateCreditDisplay() {
        try {
            const data = await fetch(`${API_BASE_URL}/user/dashboard`, { headers: getAuthHeaders() }).then(handleResponse);
            if (data.success) {
                creditBalanceEl.innerHTML = `<span>Créditos: ${data.data.credits.toLocaleString()}</span>`;
            }
        } catch (error) {
            console.error('Failed to update credit display:', error);
            creditBalanceEl.innerHTML = `<span>Créditos: --</span>`;
        }
    }

    // Mostrar notificaciones
    function showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = message;
        
        const bgColor = type === 'warning' ? 
            'linear-gradient(45deg, #ff6b6b, #ffd93d)' : 
            'linear-gradient(45deg, #00ffff, #4169e1)';
        
        notification.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: ${bgColor};
            color: #000;
            padding: 1rem 1.5rem;
            border-radius: 10px;
            font-weight: 600;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            animation: slideInFromBottom 0.3s ease-out;
            z-index: 1000;
        `;

        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOutToBottom 0.3s ease-in';
            setTimeout(() => notification.remove(), 300);
        }, 5000);
    }

    // Función para crear un selector de pares mejorado con dropdown visible
    function createEnhancedPairSelector() {
        const pairSelector = document.getElementById('pairSelector');
        const pairSelectorParent = pairSelector.parentElement;
        
        // Crear contenedor para el selector mejorado
        const selectorContainer = document.createElement('div');
        selectorContainer.style.cssText = `
            position: relative;
            display: inline-block;
        `;
        
        // Crear botón de dropdown
        const dropdownButton = document.createElement('button');
        dropdownButton.innerHTML = '▼';
        dropdownButton.style.cssText = `
            position: absolute;
            right: 5px;
            top: 50%;
            transform: translateY(-50%);
            background: transparent;
            border: none;
            color: #00ffff;
            cursor: pointer;
            padding: 5px;
            font-size: 12px;
            z-index: 2;
        `;
        
        // Crear lista desplegable
        const dropdownList = document.createElement('div');
        dropdownList.id = 'pairDropdownList';
        dropdownList.style.cssText = `
            position: absolute;
            top: 100%;
            left: 0;
            width: 350px;
            max-height: 500px;
            overflow-y: auto;
            background: rgba(10, 10, 15, 0.98);
            border: 1px solid rgba(0, 255, 255, 0.3);
            border-radius: 10px;
            margin-top: 5px;
            display: none;
            z-index: 1000;
            backdrop-filter: blur(20px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        `;
        
        // Agregar barra de búsqueda
        const searchBar = document.createElement('input');
        searchBar.type = 'text';
        searchBar.placeholder = '🔍 Buscar par...';
        searchBar.style.cssText = `
            width: calc(100% - 20px);
            margin: 10px;
            padding: 8px 12px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(0, 255, 255, 0.2);
            border-radius: 8px;
            color: #00ffff;
            font-size: 14px;
            outline: none;
        `;
        
        // Contenedor para los pares
        const pairListContainer = document.createElement('div');
        pairListContainer.style.cssText = `
            max-height: 450px;
            overflow-y: auto;
            padding: 5px;
        `;
        
        // Función para poblar la lista
        function populatePairList(filter = '') {
            pairListContainer.innerHTML = '';
            
            // Categorías de pares
            const categories = {
                '🔥 Principales': ['BTCUSDT', 'ETHUSDT', 'BNBUSDT'],
                '📈 Top 10': ['SOLUSDT', 'XRPUSDT', 'DOGEUSDT', 'ADAUSDT', 'AVAXUSDT', 'DOTUSDT', 'TRXUSDT'],
                '💎 DeFi': ['LINKUSDT', 'UNIUSDT', 'AAVEUSDT', 'SUSHIUSDT', 'MATICUSDT'],
                '🐕 Meme Coins': ['SHIBUSDT', 'PEPEUSDT', 'FLOKIUSDT'],
                '⚡ Layer 2': ['ARBUSDT', 'OPUSDT'],
                '🤖 AI & Gaming': ['FETUSDT', 'RENDERUSDT', 'AXSUSDT', 'SANDUSDT', 'MANAUSDT', 'GALAUSDT'],
                '📊 Otros': []
            };
            
            // Clasificar todos los pares
            const categorizedPairs = {};
            Object.keys(categories).forEach(cat => categorizedPairs[cat] = []);
            
            if (window.availablePairs) {
                window.availablePairs.forEach(pair => {
                    let categorized = false;
                    for (const [category, symbols] of Object.entries(categories)) {
                        if (symbols.includes(pair.id)) {
                            categorizedPairs[category].push(pair);
                            categorized = true;
                            break;
                        }
                    }
                    if (!categorized) {
                        categorizedPairs['📊 Otros'].push(pair);
                    }
                });
            }
            
            // Mostrar pares por categoría
            Object.entries(categorizedPairs).forEach(([category, pairs]) => {
                if (pairs.length === 0) return;
                
                // Filtrar pares
                const filteredPairs = pairs.filter(pair => 
                    pair.id.toLowerCase().includes(filter.toLowerCase()) ||
                    pair.name.toLowerCase().includes(filter.toLowerCase())
                );
                
                if (filteredPairs.length === 0) return;
                
                // Header de categoría
                const categoryHeader = document.createElement('div');
                categoryHeader.style.cssText = `
                    padding: 8px 12px;
                    color: #00ffff;
                    font-size: 12px;
                    font-weight: 600;
                    opacity: 0.8;
                    border-bottom: 1px solid rgba(0, 255, 255, 0.1);
                    margin: 5px 0;
                    background: rgba(0, 255, 255, 0.05);
                    border-radius: 5px;
                `;
                categoryHeader.textContent = category;
                pairListContainer.appendChild(categoryHeader);
                
                // Items de pares
                filteredPairs.forEach(pair => {
                    const pairItem = document.createElement('div');
                    pairItem.style.cssText = `
                        padding: 10px 15px;
                        cursor: pointer;
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                        transition: all 0.2s ease;
                        border-radius: 8px;
                        margin: 2px 0;
                    `;
                    
                    const pairInfo = document.createElement('div');
                    pairInfo.style.cssText = `
                        display: flex;
                        align-items: center;
                        gap: 10px;
                    `;
                    
                    const pairName = document.createElement('span');
                    pairName.style.cssText = `
                        color: #ffffff;
                        font-weight: 500;
                        font-size: 14px;
                    `;
                    pairName.textContent = pair.name;
                    
                    const pairSymbol = document.createElement('span');
                    pairSymbol.style.cssText = `
                        color: rgba(255, 255, 255, 0.5);
                        font-size: 12px;
                    `;
                    pairSymbol.textContent = pair.id;
                    
                    // Indicador si es el par actual
                    if (pairSelector.value === pair.id) {
                        const currentBadge = document.createElement('span');
                        currentBadge.style.cssText = `
                            background: rgba(0, 255, 100, 0.2);
                            color: #00ff64;
                            padding: 2px 6px;
                            border-radius: 4px;
                            font-size: 10px;
                            margin-left: auto;
                        `;
                        currentBadge.textContent = 'ACTUAL';
                        pairItem.appendChild(currentBadge);
                    }
                    
                    pairInfo.appendChild(pairName);
                    pairItem.appendChild(pairInfo);
                    pairItem.appendChild(pairSymbol);
                    
                    // Hover effect
                    pairItem.onmouseover = () => {
                        pairItem.style.background = 'rgba(0, 255, 255, 0.1)';
                        pairItem.style.transform = 'translateX(5px)';
                    };
                    pairItem.onmouseout = () => {
                        pairItem.style.background = 'transparent';
                        pairItem.style.transform = 'translateX(0)';
                    };
                    
                    // Click handler
                    pairItem.onclick = () => {
                        pairSelector.value = pair.id;
                        dropdownList.style.display = 'none';
                        loadTradingViewWidget(pair.id);
                        showNotification(`Par cambiado a ${pair.name}`, 'info');
                    };
                    
                    pairListContainer.appendChild(pairItem);
                });
            });
            
            if (pairListContainer.children.length === 0) {
                const noResults = document.createElement('div');
                noResults.style.cssText = `
                    padding: 20px;
                    text-align: center;
                    color: rgba(255, 255, 255, 0.5);
                `;
                noResults.textContent = 'No se encontraron pares';
                pairListContainer.appendChild(noResults);
            }
        }
        
        // Event handlers
        dropdownButton.onclick = (e) => {
            e.stopPropagation();
            const isVisible = dropdownList.style.display === 'block';
            dropdownList.style.display = isVisible ? 'none' : 'block';
            if (!isVisible) {
                populatePairList();
                searchBar.value = '';
                searchBar.focus();
            }
        };
        
        // Click en el input también abre el dropdown
        pairSelector.onclick = (e) => {
            e.stopPropagation();
            dropdownList.style.display = 'block';
            populatePairList();
            searchBar.focus();
        };
        
        // Búsqueda en tiempo real
        searchBar.oninput = (e) => {
            populatePairList(e.target.value);
        };
        
        // Prevenir cierre al hacer click dentro
        dropdownList.onclick = (e) => {
            e.stopPropagation();
        };
        
        // Cerrar al hacer click fuera
        document.addEventListener('click', () => {
            dropdownList.style.display = 'none';
        });
        
        // Ajustar padding del input
        pairSelector.style.paddingRight = '30px';
        
        // Construir el selector
        dropdownList.appendChild(searchBar);
        dropdownList.appendChild(pairListContainer);
        
        // Insertar en el DOM
        pairSelectorParent.insertBefore(selectorContainer, pairSelector);
        selectorContainer.appendChild(pairSelector);
        selectorContainer.appendChild(dropdownButton);
        selectorContainer.appendChild(dropdownList);
        
        // Estilo para scrollbar
        const style = document.createElement('style');
        style.textContent = `
            #pairDropdownList::-webkit-scrollbar,
            #pairDropdownList div::-webkit-scrollbar {
                width: 8px;
            }
            #pairDropdownList::-webkit-scrollbar-track,
            #pairDropdownList div::-webkit-scrollbar-track {
                background: rgba(255, 255, 255, 0.05);
                border-radius: 4px;
            }
            #pairDropdownList::-webkit-scrollbar-thumb,
            #pairDropdownList div::-webkit-scrollbar-thumb {
                background: rgba(0, 255, 255, 0.3);
                border-radius: 4px;
            }
            #pairDropdownList::-webkit-scrollbar-thumb:hover,
            #pairDropdownList div::-webkit-scrollbar-thumb:hover {
                background: rgba(0, 255, 255, 0.5);
            }
        `;
        document.head.appendChild(style);
    }

    // Detectar cambios significativos
    function checkSignificantChanges(oldData, newData) {
        if (!oldData || !newData) return;
        
        const oldSignal = oldData.finalAnalysis?.signal;
        const newSignal = newData.finalAnalysis?.signal;
        
        if (oldSignal && newSignal && oldSignal !== newSignal) {
            showNotification(`⚠️ Cambio de señal: ${oldSignal} → ${newSignal}`, 'warning');
        }
    }

    // --- ATAJOS DE TECLADO ---
    document.addEventListener('keydown', (e) => {
        // Ctrl/Cmd + K para enfocar búsqueda
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            pairSelector.focus();
            pairSelector.select();
        }
        
        // Enter para analizar cuando el selector está enfocado
        if (e.key === 'Enter' && document.activeElement === pairSelector) {
            e.preventDefault();
            performAnalysis();
        }
        
        // Escape para limpiar búsqueda
        if (e.key === 'Escape' && document.activeElement === pairSelector) {
            pairSelector.value = '';
        }
    });

    // --- Render Functions ---
    function renderAnalysisSummary(analysis) {
        if (!analysis || !analysis.counts) {
            analysisSummaryCard.innerHTML = `
                <center>
                    <h3>Análisis Final</h3>
                    <p style="color: rgba(255,255,255,0.6); margin-top: 20px;">
                        Selecciona un par y presiona "Analizar" para ver el análisis
                    </p>
                </center>
            `;
            return;
        }
        const { signal, confidence, summary, counts } = analysis;
        const signalColor = signal === 'Compra' ? '#00ff64' : signal === 'Venta' ? '#ff3232' : '#8a2be2';

        analysisSummaryCard.innerHTML = `
            <center><h3>Análisis Final</h3>
            <h4>Confianza de la Señal</h4></center>

            <div class="signal-general">
                <div class="signal-badge-center" style="background-color: ${signalColor};">${signal}</div>
                <div>Señal General</div>
            </div>

            <div class="confidence-circle" style="--signal-color: ${signalColor}; --confidence-angle: ${confidence / 100 * 360}deg;">
                <div class="circle-bg">
                    <span class="confidence-text">${confidence}%</span>
                </div>
            </div>

            <div style="margin-top: 1.5rem;">
                <h4>Resumen</h4>
                <p>${summary}</p>
                <p style="margin-top: 1rem;"><strong>Desglose de Indicadores (30 total):</strong></p>
                <span class="signal-compra">Compra: ${counts.buy}</span>
                <span class="signal-venta">Venta: ${counts.sell}</span>
                <span class="signal-neutral">Neutral: ${counts.neutral}</span>
            </div>
        `;
    }

    function renderMarketData(data) {
        if (!data) {
            marketDataCard.innerHTML = `
                <h3>⚡ Datos de Mercado</h3>
                <p style="color: rgba(255,255,255,0.6); text-align: center; margin-top: 20px;">
                    Sin datos disponibles
                </p>
            `;
            return;
        }
        
        const priceChangePercent = parseFloat(data.priceChangePercent);
        const changeColor = priceChangePercent >= 0 ? '#00ff64' : '#ff3232';
        const formatNumber = (num) => {
            if (num >= 1_000_000_000) return `${(num / 1_000_000_000).toFixed(2)}B`;
            if (num >= 1_000_000) return `${(num / 1_000_000).toFixed(2)}M`;
            return parseFloat(num).toLocaleString();
        };

        marketDataCard.innerHTML = `
            <h3>⚡ Datos de Mercado</h3>
            <ul class="sidebar-list">
                <li><span>Precio Actual</span><span>$${parseFloat(data.lastPrice).toFixed(2)}</span></li>
                <li><span>Cambio 24h</span><span style="color: ${changeColor};">${priceChangePercent.toFixed(2)}%</span></li>
                <li><span>Volumen 24h (USDT)</span><span>${formatNumber(data.quoteVolume)}</span></li>
                <li><span>Máximo 24h</span><span>$${parseFloat(data.highPrice).toFixed(2)}</span></li>
                <li><span>Mínimo 24h</span><span>$${parseFloat(data.lowPrice).toFixed(2)}</span></li>
            </ul>
        `;
    }

    function renderKeyIndicators(indicators) {
        if (!indicators) {
            keyIndicatorsCard.innerHTML = `
                <h3>🔍 Indicadores Clave</h3>
                <p style="color: rgba(255,255,255,0.6); text-align: center; margin-top: 20px;">
                    Sin datos disponibles
                </p>
            `;
            return;
        }
        
        const getIndicator = (name) => indicators[name] || { value: 'N/A', signal: 'Neutral' };
        const rsi = getIndicator('RSI');
        const macd = getIndicator('MACD');
        const ema50 = getIndicator('EMA 50');
        const sma200 = getIndicator('SMA 200');

        keyIndicatorsCard.innerHTML = `
            <h3>🔍 Indicadores Clave</h3>
            <ul class="sidebar-list">
                <li><span>RSI (14)</span><span>${typeof rsi.value === 'number' ? rsi.value.toFixed(2) : rsi.value}</span></li>
                <li><span>MACD Signal</span><span class="signal-${macd.signal.toLowerCase()}">${macd.signal}</span></li>
                <li><span>EMA 50</span><span>$${typeof ema50.value === 'number' ? ema50.value.toFixed(2) : ema50.value}</span></li>
                <li><span>SMA 200</span><span>$${typeof sma200.value === 'number' ? sma200.value.toFixed(2) : sma200.value}</span></li>
            </ul>
        `;
    }

    function renderNews(newsItems) {
        let content = '<h3>📰 Noticias Crypto</h3>';
        if (!newsItems || newsItems.length === 0) {
            content += '<p style="color: rgba(255,255,255,0.6); text-align: center; margin-top: 20px;">Sin noticias disponibles</p>';
        } else {
            newsItems.forEach(item => {
                content += `
                    <div class="news-item">
                        <a href="${item.link}" target="_blank" rel="noopener noreferrer" class="news-title">${item.title}</a>
                        <div class="news-meta">${new Date(item.pubDate).toLocaleString()}</div>
                    </div>
                `;
            });
        }
        newsFeedCard.innerHTML = content;
    }

    function renderIndicatorGrid(indicators) {
        if (!indicators) {
            indicatorsGrid.innerHTML = '<p style="color: rgba(255,255,255,0.6); text-align: center;">Presiona "Analizar" para ver los indicadores</p>';
            return;
        }
        
        let content = '';
        for (const [name, data] of Object.entries(indicators)) {
            const signalClass = `signal-${data.signal.toLowerCase().replace(' ', '-')}`;
            const value = typeof data.value === 'number' ? data.value.toFixed(2) : 
                          typeof data.value === 'object' ? 'Calculado' : data.value;
            
            content += `
                <div class="indicator-card">
                    <div class="indicator-name">${name}</div>
                    <div class="indicator-value">${value}</div>
                    <div class="indicator-signal ${signalClass}">${data.signal}</div>
                </div>
            `;
        }
        indicatorsGrid.innerHTML = content;
    }

    function loadTradingViewWidget(symbol) {
        if (!symbol) return;
        
        if (tradingViewWidget) {
            tradingViewWidget.remove();
        }
        
        const interval = timeSelector.value === '1m' ? '1' :
                        timeSelector.value === '5m' ? '5' :
                        timeSelector.value === '15m' ? '15' :
                        timeSelector.value === '30m' ? '30' :
                        timeSelector.value === '1h' ? '60' :
                        timeSelector.value === '4h' ? '240' :
                        timeSelector.value === '1d' ? 'D' :
                        timeSelector.value === '1w' ? 'W' : '15';
        
        tradingViewWidget = new TradingView.widget({
            "autosize": true,
            "symbol": `BINANCE:${symbol}`,
            "interval": interval,
            "timezone": "Etc/UTC",
            "theme": "dark",
            "style": "1",
            "locale": "es",
            "toolbar_bg": "#f1f3f6",
            "enable_publishing": false,
            "allow_symbol_change": false,
            "container_id": "chartContainer"
        });
    }

    // --- Main Analysis Function ---
    async function performAnalysis() {
        const symbol = pairSelector.value.toUpperCase();
        const interval = timeSelector.value;

        const isValidPair = Array.from(pairList.options).some(opt => opt.value === symbol);
        if (!symbol || !isValidPair) {
            showNotification('Por favor, seleccione un par válido de la lista.', 'warning');
            if (!isValidPair) pairSelector.value = '';
            return;
        }

        // Guardar último par analizado
        saveLastPair(symbol);

        analyzeBtn.innerHTML = '<span class="btn-icon">⏳</span> Analizando...';
        analyzeBtn.disabled = true;

        try {
            const fetchOptions = { headers: getAuthHeaders() };
            const [analysisData, marketData, news] = await Promise.all([
                fetch(`${API_BASE_URL}/analysis?symbol=${symbol}&interval=${interval}`, fetchOptions).then(handleResponse),
                fetch(`${API_BASE_URL}/market-data?symbol=${symbol}`, fetchOptions).then(handleResponse),
                fetch(`${API_BASE_URL}/news`, fetchOptions).then(handleResponse)
            ]);

            updateCreditDisplay(); // Update credits after successful analysis

            // Detectar cambios significativos
            checkSignificantChanges(lastAnalysisData, analysisData);
            lastAnalysisData = analysisData;

            // Render all components
            renderAnalysisSummary(analysisData.finalAnalysis);
            renderMarketData(marketData);
            renderKeyIndicators(analysisData.indicators);
            renderNews(news);
            renderIndicatorGrid(analysisData.indicators);
            
            // Actualizar el gráfico con el intervalo correcto
            loadTradingViewWidget(symbol);
            
            showNotification(`✅ Análisis completado para ${symbol}`, 'info');
            
            // Iniciar auto-refresh SOLO después de un análisis exitoso
            startAutoRefresh();

        } catch (error) {
            showNotification(`Error: ${error.message}`, 'warning');
            console.error(error);
        } finally {
            analyzeBtn.innerHTML = '<span class="btn-icon">🔍</span> Analizar';
            analyzeBtn.disabled = false;
        }
    }

    // Función para iniciar auto-refresh
    function startAutoRefresh() {
        // Limpiar intervalo anterior si existe
        if (autoRefreshInterval) {
            clearInterval(autoRefreshInterval);
        }
        
        // Auto-refresh cada 30 segundos SOLO si ya se hizo un análisis
        autoRefreshInterval = setInterval(async () => {
            const symbol = pairSelector.value.toUpperCase();
            const interval = timeSelector.value;
            
            if (!symbol) return;
            
            try {
                const fetchOptions = { headers: getAuthHeaders() };
                const [analysisData, marketData] = await Promise.all([
                    fetch(`${API_BASE_URL}/analysis?symbol=${symbol}&interval=${interval}`, fetchOptions).then(handleResponse),
                    fetch(`${API_BASE_URL}/market-data?symbol=${symbol}`, fetchOptions).then(handleResponse)
                ]);
                
                checkSignificantChanges(lastAnalysisData, analysisData);
                lastAnalysisData = analysisData;

                // Actualizar silenciosamente sin notificaciones
                renderAnalysisSummary(analysisData.finalAnalysis);
                renderMarketData(marketData);
                renderKeyIndicators(analysisData.indicators);
                renderIndicatorGrid(analysisData.indicators);
            } catch (error) {
                console.error('Error en auto-refresh:', error);
            }
        }, 30000);
    }

    async function initialize() {
        // Agregar estilos para animaciones
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideInFromBottom {
                from { transform: translateY(100%); opacity: 0; }
                to { transform: translateY(0); opacity: 1; }
            }
            @keyframes slideOutToBottom {
                from { transform: translateY(0); opacity: 1; }
                to { transform: translateY(100%); opacity: 0; }
            }
        `;
        document.head.appendChild(style);

        // Create animated background
        const particles = document.createElement('div');
        particles.className = 'background-particles';
        document.body.prepend(particles);
        for (let i = 0; i < 50; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            particle.style.left = Math.random() * 100 + '%';
            particle.style.top = Math.random() * 100 + '%';
            particle.style.animationDelay = Math.random() * 6 + 's';
            particle.style.animationDuration = (Math.random() * 4 + 4) + 's';
            particles.appendChild(particle);
        }

        // Verificar estado del backend
        const backendOnline = await checkBackendStatus();
        if (!backendOnline) {
            showNotification('⚠️ Backend sin conexión. Verificando...', 'warning');
        }

        // Fetch pairs and populate selector
        try {
            const pairs = await fetch(`${API_BASE_URL}/pairs`, { headers: getAuthHeaders() }).then(handleResponse);
            window.availablePairs = pairs;
            
            pairs.forEach(pair => {
                const option = document.createElement('option');
                option.value = pair.id;
                option.textContent = pair.name;
                pairList.appendChild(option);
            });
            
            // ❌ Se eliminó: showPairCount(pairs.length);
            // ❌ Se eliminó: addPopularPairsButtons(pairs);

            // Cargar último par o usar default
            const lastPair = loadLastPair();
            pairSelector.value = lastPair;
            
            // Cargar SOLO el gráfico del par seleccionado, NO analizar
            loadTradingViewWidget(lastPair);
            
            showNotification(`✅ ${pairs.length} pares cargados. Selecciona un par y presiona "Analizar"`, 'info');
            
        } catch (error) {
            console.error("Failed to fetch trading pairs:", error);
            
            const emergencyPairs = [
                { id: 'BTCUSDT', name: 'BTC/USDT' },
                { id: 'ETHUSDT', name: 'ETH/USDT' },
                { id: 'BNBUSDT', name: 'BNB/USDT' }
            ];
            
            emergencyPairs.forEach(pair => {
                const option = document.createElement('option');
                option.value = pair.id;
                option.textContent = pair.name;
                pairList.appendChild(option);
            });
            
            pairSelector.value = 'BTCUSDT';
            loadTradingViewWidget('BTCUSDT');
            showNotification("⚠️ Usando pares de emergencia", 'warning');
        }

        // Event listeners
        analyzeBtn.addEventListener('click', performAnalysis);
        
        // Cambiar gráfico cuando se cambia el par (SIN analizar)
        pairSelector.addEventListener('change', () => {
            const symbol = pairSelector.value;
            if (symbol) {
                loadTradingViewWidget(symbol);
            }
        });
        
        // Cambiar intervalo del gráfico cuando se cambia la temporalidad (SIN analizar)
        timeSelector.addEventListener('change', () => {
            const symbol = pairSelector.value;
            if (symbol) {
                loadTradingViewWidget(symbol);
            }
        });

        // NO realizar análisis inicial automático
        
        // Verificar estado del backend cada minuto
        setInterval(checkBackendStatus, 60000);

        // Crear el selector mejorado con dropdown
        createEnhancedPairSelector();

        // Fetch initial credit balance
        updateCreditDisplay();
    }

    initialize();
});